package com.example.projetcoachnutrition.Modele;

import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class Repas {

    private int id;
    private Date date;
    private String Sdate;
    private double totalCalories = 0;
    public ArrayList<Aliment> lesAliments;
    private Integer[] enregId; //stocke les id des aliments
    private int selectQte;


    public Repas(int id, Date ladate, ArrayList<Aliment> lsAliment, int selectqte) {
        this.id = id;
        this.date = ladate;
        lesAliments = new ArrayList<>();
        this.lesAliments = lsAliment;
        this.selectQte = selectqte;

    }

    public Repas(int id, String ladate,float colories){
        this.id = id;
        this.Sdate = ladate;
        this.totalCalories = colories;
    }

    public int getId() {
        return id;
    }

    public Date getDate() {
        return date;
    }

    /**
     * parcours la liste et retourne la somme des calories
     * @return
     */
    public double getTotalCalories() {
        int premierId = lesAliments.get(0).getId();
        for (Aliment unAliment : lesAliments){
            if(premierId == unAliment.getId()){
                totalCalories = unAliment.getCalories()*selectQte;
            }else{
                totalCalories = totalCalories + (unAliment.getCalories() * selectQte);
            }
        }
        return totalCalories;
    }

    /**
     * retourne les id de tous les aliments du repas
     * @return
      */
    public Integer[] getAllId(){
        this.enregId = new Integer[lesAliments.size()];
        int i = 0;

        for (Aliment unAliment : lesAliments){
            enregId[i] = unAliment.getId();
            i++;
        }
        supprimer_doublon(enregId);
        return enregId;
    }


    public void setId(int id){
        this.id = id;
    }

    public void setList(ArrayList<Aliment> lesaliment){
        this.lesAliments = lesaliment;
    }

    public String getSdate(){
        return  this.Sdate;
    }

    public double calorieReturn(){
        return this.totalCalories;
    }

    /**
     * suppression des doublons dans une liste
     * @param args
     * @return
     */
    public static Object[] supprimer_doublon(Object[] args)
    {
        List list = Arrays.asList(args);
        Set set = new HashSet(list);
        Object[] result = new Object[set.size()];
        set.toArray(result);
        return result;
    }

    public void setLesAliments(Aliment aliment){
        this.lesAliments.add(aliment);
    }

    public double getCalories(){
        return this.totalCalories;
    }
}
